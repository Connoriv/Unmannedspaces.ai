/* @ds-bundle: {"format":4,"namespace":"ShiftFreeDesignSystem_a724fd","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CheckItem","sourcePath":"components/core/CheckItem.jsx"},{"name":"ChoiceChip","sourcePath":"components/core/ChoiceChip.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Pill","sourcePath":"components/core/Pill.jsx"},{"name":"StatTile","sourcePath":"components/core/StatTile.jsx"},{"name":"BrandMarquee","sourcePath":"components/marketing/BrandMarquee.jsx"},{"name":"CtaBand","sourcePath":"components/marketing/CtaBand.jsx"},{"name":"DataTable","sourcePath":"components/marketing/DataTable.jsx"},{"name":"FaqItem","sourcePath":"components/marketing/FaqItem.jsx"},{"name":"Footnote","sourcePath":"components/marketing/Footnote.jsx"},{"name":"HubCard","sourcePath":"components/marketing/HubCard.jsx"},{"name":"PainCard","sourcePath":"components/marketing/PainCard.jsx"},{"name":"PriceCard","sourcePath":"components/marketing/PriceCard.jsx"},{"name":"SectionHeading","sourcePath":"components/marketing/SectionHeading.jsx"},{"name":"StepRow","sourcePath":"components/marketing/StepRow.jsx"},{"name":"SiteFooter","sourcePath":"components/navigation/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/navigation/SiteHeader.jsx"}],"sourceHashes":{"components/core/Button.jsx":"5dce62e14fff","components/core/Card.jsx":"3fdc481db15d","components/core/CheckItem.jsx":"6707e6d3e7c3","components/core/ChoiceChip.jsx":"1b3eeabfe685","components/core/Eyebrow.jsx":"288d6e243678","components/core/Pill.jsx":"2b6f8f73da0f","components/core/StatTile.jsx":"87376620aef6","components/marketing/BrandMarquee.jsx":"0c64b289667a","components/marketing/CtaBand.jsx":"b9f1af4e820d","components/marketing/DataTable.jsx":"d4b084f2da3a","components/marketing/FaqItem.jsx":"fa856c75a346","components/marketing/Footnote.jsx":"f5746a5a02bd","components/marketing/HubCard.jsx":"2fb60aeb9972","components/marketing/PainCard.jsx":"42a9c4198e2a","components/marketing/PriceCard.jsx":"55ae4880572c","components/marketing/SectionHeading.jsx":"151262f35793","components/marketing/StepRow.jsx":"d563b709c0f6","components/navigation/SiteFooter.jsx":"bfbc1167e6e5","components/navigation/SiteHeader.jsx":"0e5223cb0591","ui_kits/website/App.jsx":"adf41fa8afc0","ui_kits/website/CompanyScreen.jsx":"318bb07c3748","ui_kits/website/HomeScreen.jsx":"0ac71103d3ea","ui_kits/website/PricingScreen.jsx":"007b13d4bfdf","ui_kits/website/RevenueScreen.jsx":"4732c06a4c32","ui_kits/website/Shell.jsx":"83de9b2d9eb1","ui_kits/website/SystemScreen.jsx":"8a98a86d4ddb","ui_kits/website/content.js":"4825255001d2"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ShiftFreeDesignSystem_a724fd = window.ShiftFreeDesignSystem_a724fd || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BASE = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '10px',
  fontFamily: 'var(--sf-font-display)',
  fontWeight: 700,
  letterSpacing: '-0.01em',
  borderRadius: 'var(--sf-radius-pill)',
  textDecoration: 'none',
  cursor: 'pointer',
  border: '1px solid transparent',
  whiteSpace: 'nowrap',
  transition: 'var(--sf-transition-hover), filter var(--sf-dur-fast) var(--sf-ease)'
};
const SIZES = {
  sm: {
    fontSize: '14px',
    padding: '11px 20px'
  },
  md: {
    fontSize: '15px',
    padding: '15px 26px'
  },
  lg: {
    fontSize: '16px',
    padding: '16px 30px'
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--sf-accent-gradient)',
    color: 'var(--sf-text-on-accent)'
  },
  secondary: {
    background: 'transparent',
    color: 'var(--sf-fg-3)',
    borderColor: 'var(--sf-border-strong)',
    fontWeight: 600
  },
  outlineAccent: {
    background: 'transparent',
    color: 'var(--sf-text-accent-soft)',
    borderColor: 'var(--sf-teal-a30)',
    fontWeight: 600
  },
  solidAccent: {
    background: 'var(--sf-accent-solid)',
    color: 'var(--sf-text-on-accent)'
  },
  mono: {
    background: 'transparent',
    color: 'var(--sf-fg-3)',
    borderColor: 'var(--sf-border-strong)',
    fontFamily: 'var(--sf-font-mono)',
    fontWeight: 400,
    letterSpacing: '0.04em'
  }
};
const HOVER = {
  primary: {
    filter: 'brightness(1.08)'
  },
  solidAccent: {
    filter: 'brightness(1.08)'
  },
  secondary: {
    borderColor: 'var(--sf-border-accent-hover)',
    color: 'var(--sf-teal-300)'
  },
  outlineAccent: {
    background: 'var(--sf-teal-a08)'
  },
  mono: {
    borderColor: 'var(--sf-border-accent-hover)',
    color: 'var(--sf-teal-300)'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'lg',
  href,
  disabled,
  fullWidth,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = Object.assign({}, BASE, SIZES[size] || SIZES.lg, VARIANTS[variant] || VARIANTS.primary, hover && !disabled ? HOVER[variant] : null, fullWidth ? {
    width: '100%'
  } : null, disabled ? {
    opacity: 0.4,
    pointerEvents: 'none'
  } : null, style);
  const handlers = {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick,
    style: s
  };
  return href ? /*#__PURE__*/React.createElement("a", _extends({
    href: href
  }, handlers, rest), children) : /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled
  }, handlers, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  children,
  tone = 'default',
  pad = 'md',
  radius = 'card',
  hoverable = false,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const accent = tone === 'accent';
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: hoverable ? () => setHover(true) : undefined,
    onMouseLeave: hoverable ? () => setHover(false) : undefined,
    style: Object.assign({
      background: accent ? 'var(--sf-accent-wash)' : hover ? 'var(--sf-surface-card-hover)' : 'var(--sf-surface-card)',
      border: accent ? '1px solid var(--sf-border-accent)' : '1px solid var(--sf-border-default)',
      borderRadius: radius === 'panel' ? 'var(--sf-radius-panel)' : radius === 'md' ? 'var(--sf-radius-md)' : 'var(--sf-radius-card)',
      padding: pad === 'sm' ? '16px 18px' : pad === 'lg' ? 'var(--sf-card-pad-lg)' : 'var(--sf-card-pad)',
      display: 'flex',
      flexDirection: 'column',
      transition: 'var(--sf-transition-hover)'
    }, style)
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/CheckItem.jsx
try { (() => {
function CheckItem({
  children,
  state = 'yes',
  style
}) {
  return /*#__PURE__*/React.createElement("li", {
    style: Object.assign({
      display: 'flex',
      gap: '14px',
      alignItems: 'flex-start',
      listStyle: 'none'
    }, style)
  }, state === 'yes' ? /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--sf-teal)",
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: '18px',
      height: '18px',
      marginTop: '3px'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  })) : /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      width: '18px',
      height: '18px',
      borderRadius: 'var(--sf-radius-pill)',
      border: '1px solid rgba(180,140,140,0.4)',
      marginTop: '3px',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 1.55,
      color: state === 'yes' ? 'var(--sf-fg-4)' : 'var(--sf-fg-9)',
      textWrap: 'pretty'
    }
  }, children));
}
Object.assign(__ds_scope, { CheckItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/CheckItem.jsx", error: String((e && e.message) || e) }); }

// components/core/ChoiceChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ChoiceChip({
  children,
  active = false,
  onClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    "aria-pressed": active,
    style: Object.assign({
      cursor: 'pointer',
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '15px',
      padding: '13px 22px',
      borderRadius: 'var(--sf-radius-pill)',
      border: active ? '1px solid var(--sf-border-accent-hover)' : '1px solid var(--sf-line-20)',
      background: active ? 'var(--sf-accent-solid)' : 'transparent',
      color: active ? 'var(--sf-text-on-accent)' : 'var(--sf-fg-7)',
      transition: 'var(--sf-transition-hover)'
    }, style)
  }, rest), children);
}
Object.assign(__ds_scope, { ChoiceChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ChoiceChip.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function Eyebrow({
  children,
  tone = 'accent',
  tracking = 'eyebrow',
  as = 'p',
  style
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, {
    style: Object.assign({
      fontFamily: 'var(--sf-font-mono)',
      fontSize: tracking === 'marquee' ? '11px' : 'var(--sf-size-eyebrow)',
      letterSpacing: tracking === 'marquee' ? 'var(--sf-tracking-marquee)' : 'var(--sf-tracking-eyebrow)',
      textTransform: 'uppercase',
      color: tone === 'accent' ? 'var(--sf-text-accent)' : tone === 'muted' ? 'var(--sf-text-muted)' : 'var(--sf-text-faint)',
      margin: 0
    }, style)
  }, children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Pill.jsx
try { (() => {
function Pill({
  children,
  dot = false,
  tone = 'accent',
  style
}) {
  const accent = tone === 'accent';
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      border: accent ? '1px solid var(--sf-border-accent)' : '1px solid var(--sf-border-default)',
      background: accent ? 'var(--sf-teal-a06)' : 'transparent',
      borderRadius: 'var(--sf-radius-pill)',
      padding: '7px 14px'
    }, style)
  }, dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: 'var(--sf-radius-pill)',
      background: 'var(--sf-teal)',
      display: 'block'
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: 'var(--sf-tracking-label)',
      textTransform: 'uppercase',
      color: accent ? 'var(--sf-teal-400)' : 'var(--sf-text-muted)'
    }
  }, children));
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Pill.jsx", error: String((e && e.message) || e) }); }

// components/core/StatTile.jsx
try { (() => {
function StatTile({
  value,
  label,
  tone = 'default',
  size = 'md',
  style
}) {
  const accent = tone === 'accent';
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      border: accent ? '1px solid var(--sf-border-accent)' : '1px solid var(--sf-border-default)',
      background: accent ? 'var(--sf-accent-wash)' : 'var(--sf-ink-740)',
      borderRadius: size === 'lg' ? 'var(--sf-radius-lg)' : 'var(--sf-radius-md)',
      padding: size === 'lg' ? '26px' : '16px 18px'
    }, style)
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: size === 'lg' ? '38px' : '22px',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: accent ? 'var(--sf-teal-300)' : 'var(--sf-text-heading)',
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: size === 'lg' ? '10px 0 0' : '4px 0 0',
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-label)',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: accent ? 'var(--sf-fg-11)' : 'var(--sf-text-muted)',
      lineHeight: 1.6
    }
  }, label));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/marketing/BrandMarquee.jsx
try { (() => {
const DEFAULT_MARKS = [{
  src: 'assets/marquee/guardian.png',
  ratio: 1,
  alt: 'Guardian Entry Kit — physical door hardware'
}, {
  src: 'assets/marquee/securedoor24.png',
  ratio: 1.8125,
  alt: 'SecureDoor24 — access control'
}, {
  src: 'assets/marquee/spinwatch24.png',
  ratio: 1.8125,
  alt: 'SpinWatch24 — live monitoring and 2-way audio'
}, {
  src: 'assets/marquee/byrdview.png',
  ratio: 1.8125,
  alt: 'ByrdView — operations control center'
}, {
  src: 'assets/marquee/freebyrd.png',
  ratio: 1.8125,
  alt: 'FreeByrd — virtual customer support'
}, {
  src: 'assets/marquee/wdf-access.png',
  ratio: 1.7219,
  alt: 'WDF-Access — drop off, pick up service'
}, {
  src: 'assets/marquee/safespin24.png',
  ratio: 1.8333,
  alt: 'SafeSpin24 — the integrated system'
}];
function BrandMarquee({
  label = 'One integrated system · Six products · One dashboard',
  marks = DEFAULT_MARKS,
  height = 72,
  duration = 42,
  animate = true,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    "aria-label": "The SafeSpin24 product family",
    style: Object.assign({
      borderTop: '1px solid var(--sf-border-default)',
      borderBottom: '1px solid var(--sf-border-default)',
      background: 'var(--sf-bg-alt)',
      padding: '28px 0'
    }, style)
  }, label ? /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '11px',
      letterSpacing: 'var(--sf-tracking-marquee)',
      textTransform: 'uppercase',
      color: 'var(--sf-text-faint)',
      margin: '0 0 22px'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      overflow: 'hidden',
      maskImage: 'var(--sf-mask-marquee)',
      WebkitMaskImage: 'var(--sf-mask-marquee)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '16px',
      width: 'max-content',
      willChange: 'transform',
      animation: animate ? 'sf-marquee ' + duration + 's linear infinite' : 'none'
    }
  }, marks.concat(marks).map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    role: "img",
    "aria-label": m.alt,
    style: {
      flex: '0 0 auto',
      width: Math.round(height * m.ratio) + 'px',
      height: height + 'px',
      border: '1px solid var(--sf-border-default)',
      borderRadius: 'var(--sf-radius-md)',
      backgroundImage: 'url("' + m.src + '")',
      backgroundSize: 'auto ' + height + 'px',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat'
    }
  })))));
}
Object.assign(__ds_scope, { BrandMarquee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/BrandMarquee.jsx", error: String((e && e.message) || e) }); }

// components/marketing/CtaBand.jsx
try { (() => {
function CtaBand({
  title = 'Ready to Get Your Life Back?',
  body,
  primaryLabel = 'Schedule Your Call',
  primaryHref = '#contact',
  phone = '757-837-3567',
  trust = 'No commitment · No pressure · Just answers',
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: Object.assign({
      background: 'var(--sf-glow-cta-bottom), var(--sf-bg-page)',
      padding: '112px 24px',
      borderBottom: '1px solid var(--sf-border-default)'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '860px',
      margin: '0 auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(34px,4.8vw,60px)',
      lineHeight: 1,
      letterSpacing: 'var(--sf-tracking-hero)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 20px',
      textWrap: 'balance'
    }
  }, title), body ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: '0 0 32px',
      textWrap: 'pretty'
    }
  }, body) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '14px',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    href: primaryHref
  }, primaryLabel), phone ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "mono",
    href: 'tel:1' + String(phone).replace(/[^0-9]/g, '')
  }, "Prefer to call? ", phone) : null), trust ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-meta)',
      color: 'var(--sf-text-faint)',
      letterSpacing: 'var(--sf-tracking-meta)',
      margin: '22px 0 0'
    }
  }, trust) : null));
}
Object.assign(__ds_scope, { CtaBand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/CtaBand.jsx", error: String((e && e.message) || e) }); }

// components/marketing/DataTable.jsx
try { (() => {
function DataTable({
  columns = [],
  rows = [],
  activeRow,
  onRowActivate,
  minWidth = 560,
  style
}) {
  const th = {
    textAlign: 'left',
    fontFamily: 'var(--sf-font-mono)',
    fontWeight: 500,
    fontSize: 'var(--sf-size-label)',
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: 'var(--sf-text-muted)',
    padding: '20px 24px',
    borderBottom: '1px solid var(--sf-border-strong)',
    whiteSpace: 'nowrap'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      overflowX: 'auto',
      border: '1px solid var(--sf-border-default)',
      borderRadius: 'var(--sf-radius-card)',
      background: 'var(--sf-bg-alt)'
    }, style)
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      minWidth: minWidth + 'px',
      borderCollapse: 'collapse',
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map((c, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    scope: "col",
    style: Object.assign({}, th, i ? {
      textAlign: 'right'
    } : null)
  }, typeof c === 'string' ? c : c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, ri) => {
    const active = activeRow === ri;
    return /*#__PURE__*/React.createElement("tr", {
      key: ri,
      onMouseEnter: onRowActivate ? () => onRowActivate(ri) : undefined,
      onClick: onRowActivate ? () => onRowActivate(ri) : undefined,
      style: {
        cursor: onRowActivate ? 'pointer' : 'default',
        background: active ? 'var(--sf-teal-a08)' : 'transparent'
      }
    }, r.map((cell, ci) => ci === 0 ? /*#__PURE__*/React.createElement("th", {
      key: ci,
      scope: "row",
      style: {
        textAlign: 'left',
        fontFamily: 'var(--sf-font-display)',
        fontWeight: 700,
        fontSize: '20px',
        color: 'var(--sf-fg-2)',
        padding: '20px 24px',
        borderBottom: '1px solid var(--sf-line-08)'
      }
    }, cell) : /*#__PURE__*/React.createElement("td", {
      key: ci,
      style: {
        textAlign: 'right',
        padding: '20px 24px',
        borderBottom: '1px solid var(--sf-line-08)',
        fontSize: 'var(--sf-size-body)',
        fontFamily: active ? 'var(--sf-font-display)' : 'var(--sf-font-body)',
        fontWeight: active ? 700 : 400,
        letterSpacing: active ? '-0.01em' : 'normal',
        color: active ? 'var(--sf-teal-300)' : 'var(--sf-fg-8)',
        whiteSpace: 'nowrap'
      }
    }, cell)));
  }))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/marketing/FaqItem.jsx
try { (() => {
function FaqItem({
  question,
  answer,
  open = false,
  onToggle,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      background: 'var(--sf-bg-alt)'
    }, style)
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onToggle,
    "aria-expanded": open,
    style: {
      width: '100%',
      background: 'none',
      border: 0,
      cursor: 'pointer',
      textAlign: 'left',
      padding: '28px 30px',
      display: 'flex',
      gap: '20px',
      alignItems: 'center',
      justifyContent: 'space-between',
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'var(--sf-size-h5)',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-fg-2)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      textWrap: 'pretty'
    }
  }, question), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '22px',
      lineHeight: 1,
      color: open ? 'var(--sf-teal)' : 'var(--sf-text-muted)',
      transform: open ? 'rotate(45deg)' : 'none',
      transition: 'transform var(--sf-dur-fast) var(--sf-ease), color var(--sf-dur-fast) var(--sf-ease)'
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: open ? 'block' : 'none'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 'var(--sf-leading-prose)',
      color: 'var(--sf-text-body)',
      margin: 0,
      padding: '0 30px 30px',
      maxWidth: 'var(--sf-measure-body)',
      textWrap: 'pretty'
    }
  }, answer)));
}
Object.assign(__ds_scope, { FaqItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/FaqItem.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Footnote.jsx
try { (() => {
function Footnote({
  marker,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("p", {
    style: Object.assign({
      maxWidth: '100ch',
      fontSize: 'var(--sf-size-footnote)',
      lineHeight: 1.65,
      color: 'var(--sf-text-faint)',
      margin: 0
    }, style)
  }, marker ? /*#__PURE__*/React.createElement("sup", {
    style: {
      color: 'var(--sf-teal)'
    }
  }, marker) : null, marker ? ' ' : null, children);
}
Object.assign(__ds_scope, { Footnote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Footnote.jsx", error: String((e && e.message) || e) }); }

// components/marketing/HubCard.jsx
try { (() => {
function HubCard({
  name,
  tag,
  body,
  mark,
  markRatio = 1.8125,
  markHeight = 110,
  tone = 'default',
  linkLabel,
  linkHref,
  style
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    tone: tone,
    style: style
  }, mark ? /*#__PURE__*/React.createElement("div", {
    role: "img",
    "aria-label": name,
    style: {
      flex: '0 0 auto',
      width: Math.round(markHeight * markRatio) + 'px',
      height: markHeight + 'px',
      border: '1px solid var(--sf-border-default)',
      borderRadius: 'var(--sf-radius-lg)',
      backgroundImage: 'url("' + mark + '")',
      backgroundSize: 'auto ' + markHeight + 'px',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      marginBottom: '26px',
      alignSelf: 'flex-start'
    }
  }) : null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'var(--sf-size-h4)',
      lineHeight: 1.2,
      letterSpacing: 'var(--sf-tracking-h3)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 8px'
    }
  }, name), tag ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-label)',
      letterSpacing: 'var(--sf-tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--sf-text-accent)',
      margin: '0 0 16px'
    }
  }, tag) : null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 'var(--sf-leading-body)',
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, body), linkHref ? /*#__PURE__*/React.createElement("a", {
    href: linkHref,
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '13px',
      letterSpacing: '0.02em',
      color: 'var(--sf-link)',
      marginTop: '16px',
      display: 'inline-block'
    }
  }, linkLabel) : null);
}
Object.assign(__ds_scope, { HubCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/HubCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/PainCard.jsx
try { (() => {
function PainCard({
  num,
  question,
  answer,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: Object.assign({
      background: hover ? 'var(--sf-ink-700)' : 'var(--sf-bg-alt)',
      padding: '34px 30px',
      transition: 'var(--sf-transition-hover)'
    }, style)
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-label)',
      color: 'var(--sf-text-accent)',
      margin: '0 0 16px',
      letterSpacing: '0.12em'
    }
  }, num), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'var(--sf-size-h5)',
      lineHeight: 1.3,
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-fg-2)',
      margin: '0 0 12px',
      textWrap: 'pretty'
    }
  }, question), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body-sm)',
      lineHeight: 1.6,
      color: 'var(--sf-fg-10)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, answer));
}
Object.assign(__ds_scope, { PainCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/PainCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/PriceCard.jsx
try { (() => {
function PriceCard({
  price = '$750',
  period = '/ month',
  note,
  children,
  footnote,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      border: '1px solid var(--sf-teal-a30)',
      borderRadius: 'var(--sf-radius-panel-lg)',
      padding: '44px 38px',
      background: 'var(--sf-accent-wash)'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '10px',
      marginBottom: '8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(52px,7vw,80px)',
      lineHeight: 1,
      letterSpacing: '-0.05em',
      color: 'var(--sf-text-heading)'
    }
  }, price), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '13px',
      color: 'var(--sf-teal-300)',
      letterSpacing: '0.1em'
    }
  }, period)), note ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--sf-fg-11)',
      margin: '0 0 32px'
    }
  }, note) : null, children, footnote ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: 'var(--sf-tracking-meta)',
      color: 'var(--sf-text-muted)',
      margin: '18px 0 0',
      lineHeight: 1.7
    }
  }, footnote) : null);
}
Object.assign(__ds_scope, { PriceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/PriceCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/SectionHeading.jsx
try { (() => {
function SectionHeading({
  eyebrow,
  title,
  lead,
  size = 'h2',
  align = 'stacked',
  maxWidth = '24ch',
  style
}) {
  const titleSize = size === 'hero' ? 'var(--sf-size-hero)' : size === 'page' ? 'var(--sf-size-page-title)' : size === 'sm' ? 'var(--sf-size-h2-sm)' : 'var(--sf-size-h2)';
  const Tag = size === 'hero' || size === 'page' ? 'h1' : 'h2';
  const head = /*#__PURE__*/React.createElement(React.Fragment, null, eyebrow ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: 'var(--sf-tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--sf-text-accent)',
      margin: '0 0 16px'
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement(Tag, {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: titleSize,
      lineHeight: 'var(--sf-leading-display)',
      letterSpacing: 'var(--sf-tracking-h2)',
      color: 'var(--sf-text-heading)',
      margin: 0,
      maxWidth: maxWidth,
      textWrap: 'balance'
    }
  }, title));
  const leadEl = lead ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '17.5px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      maxWidth: 'var(--sf-measure-lead)',
      textWrap: 'pretty',
      alignSelf: align === 'split' ? 'end' : undefined
    }
  }, lead) : null;
  if (align === 'split') {
    return /*#__PURE__*/React.createElement("div", {
      style: Object.assign({
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit,minmax(340px,1fr))',
        gap: '48px',
        alignItems: 'start'
      }, style)
    }, /*#__PURE__*/React.createElement("div", null, head), leadEl);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      display: 'flex',
      flexDirection: 'column',
      gap: lead ? '20px' : 0
    }, style)
  }, head, leadEl);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/marketing/StepRow.jsx
try { (() => {
function StepRow({
  num,
  title,
  body,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: Object.assign({
      background: hover ? 'var(--sf-ink-650)' : 'var(--sf-ink-800)',
      padding: '36px 32px',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))',
      gap: '28px',
      alignItems: 'start',
      transition: 'var(--sf-transition-hover)'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '13px',
      color: 'var(--sf-teal)',
      letterSpacing: '0.1em'
    }
  }, num), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '24px',
      lineHeight: 1.14,
      letterSpacing: 'var(--sf-tracking-h3)',
      color: 'var(--sf-text-heading)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, title)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, body));
}
Object.assign(__ds_scope, { StepRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/StepRow.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteFooter.jsx
try { (() => {
const COL = {
  fontFamily: 'var(--sf-font-mono)',
  fontSize: 'var(--sf-size-label)',
  letterSpacing: '0.18em',
  textTransform: 'uppercase',
  color: 'var(--sf-text-faint)',
  margin: '0 0 20px'
};
const LINK = {
  fontSize: 'var(--sf-size-body-sm)',
  color: 'var(--sf-fg-7)',
  textDecoration: 'none'
};
function SiteFooter({
  logo = 'assets/shiftfree-logo-bw.png',
  blurb = 'Automation for unmanned spaces. Credentialed access, live monitoring, and 24/7 support — one system, one dashboard.',
  columns = [],
  legal = '© 2026 ShiftFree LLC. All rights reserved.',
  tagline = 'ShiftFree — Powered by SafeSpin24',
  style
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: Object.assign({
      background: 'var(--sf-bg-alt)',
      padding: '80px 24px 40px'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))',
      gap: '48px',
      paddingBottom: '48px',
      borderBottom: '1px solid var(--sf-border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "ShiftFree",
    style: {
      display: 'block',
      height: '52px',
      width: 'auto',
      objectFit: 'contain',
      borderRadius: 'var(--sf-radius-sm)',
      marginBottom: '20px'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body-sm)',
      lineHeight: 1.65,
      color: 'var(--sf-fg-10)',
      margin: 0,
      maxWidth: '34ch'
    }
  }, blurb)), columns.map((c, i) => /*#__PURE__*/React.createElement("nav", {
    key: i,
    "aria-label": c.title
  }, /*#__PURE__*/React.createElement("h2", {
    style: COL
  }, c.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, c.links.map((l, j) => /*#__PURE__*/React.createElement("li", {
    key: j
  }, /*#__PURE__*/React.createElement("a", {
    href: l.href,
    style: LINK
  }, l.label))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: '28px',
      display: 'flex',
      flexWrap: 'wrap',
      gap: '16px',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '12px',
      color: 'var(--sf-text-faint)',
      margin: 0,
      letterSpacing: '0.04em'
    }
  }, legal), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: '12px',
      color: 'var(--sf-text-faint)',
      margin: 0,
      letterSpacing: '0.04em'
    }
  }, tagline))));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteHeader.jsx
try { (() => {
const NAV = [{
  id: 'home',
  label: 'Home',
  href: '#home'
}, {
  id: 'system',
  label: 'The System',
  href: '#system'
}, {
  id: 'revenue',
  label: 'WDF Revenue',
  href: '#revenue'
}, {
  id: 'pricing',
  label: 'Pricing',
  href: '#pricing'
}, {
  id: 'company',
  label: 'Company',
  href: '#company'
}];
function SiteHeader({
  items = NAV,
  active = 'home',
  onNavigate,
  logo = 'assets/shiftfree-logo.png',
  tagline = 'Automation for\nunmanned spaces',
  ctaLabel = 'Schedule a Call',
  ctaHref = '#contact',
  compact = false,
  style
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: Object.assign({
      position: 'sticky',
      top: 0,
      zIndex: 60,
      background: 'var(--sf-surface-header)',
      borderBottom: '1px solid var(--sf-border-default)',
      backdropFilter: 'blur(8px)'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto',
      padding: '0 var(--sf-gutter)',
      display: 'flex',
      alignItems: 'center',
      gap: '24px',
      minHeight: 'var(--sf-header-height)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#home",
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate('home');
    } : undefined,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      flex: '0 0 auto',
      textDecoration: 'none'
    },
    "aria-label": "ShiftFree home \u2014 automation for unmanned spaces"
  }, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "ShiftFree",
    style: {
      display: 'block',
      height: 'var(--sf-header-height)',
      width: 'auto',
      objectFit: 'contain'
    }
  }), !compact && tagline ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 600,
      fontSize: '15px',
      lineHeight: 1.28,
      letterSpacing: '-0.015em',
      color: 'var(--sf-teal-300)',
      paddingLeft: '16px',
      borderLeft: '1px solid var(--sf-teal-a26)',
      whiteSpace: 'pre-line'
    }
  }, tagline) : null), /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Primary",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '2px',
      marginLeft: 'auto',
      overflowX: 'auto',
      scrollbarWidth: 'none'
    }
  }, items.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.id,
    href: n.href,
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate(n.id);
    } : undefined,
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 600,
      fontSize: '13.5px',
      letterSpacing: '-0.005em',
      padding: '8px 11px',
      borderRadius: 'var(--sf-radius-pill)',
      whiteSpace: 'nowrap',
      textDecoration: 'none',
      color: active === n.id ? 'var(--sf-text-on-accent)' : 'var(--sf-fg-7)',
      background: active === n.id ? 'var(--sf-accent-solid)' : 'transparent'
    }
  }, n.label))), !compact ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    href: ctaHref,
    onClick: onNavigate ? e => {
      e.preventDefault();
      onNavigate('company');
    } : undefined
  }, ctaLabel) : null));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
const {
  SiteHeader,
  SiteFooter
} = window.ShiftFreeDesignSystem_a724fd;
function App() {
  const C = window.SF_CONTENT;
  const [page, setPage] = React.useState('home');
  const go = p => {
    setPage(p);
    window.scrollTo(0, 0);
  };
  const Screen = {
    home: HomeScreen,
    system: SystemScreen,
    revenue: RevenueScreen,
    pricing: PricingScreen,
    company: CompanyScreen
  }[page];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--sf-bg-page)',
      minHeight: '100vh',
      overflowX: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(SiteHeader, {
    items: C.nav,
    active: page,
    onNavigate: go,
    logo: C.A + 'shiftfree-logo.png'
  }), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Screen, {
    go: go
  })), /*#__PURE__*/React.createElement(SiteFooter, {
    logo: C.A + 'shiftfree-logo-bw.png',
    columns: C.footerColumns
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CompanyScreen.jsx
try { (() => {
const {
  SectionHeading,
  StatTile,
  Button,
  Eyebrow
} = window.ShiftFreeDesignSystem_a724fd;
function CompanyScreen() {
  const C = window.SF_CONTENT;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    pad: "md",
    glow: "radial-gradient(900px 480px at 78% -10%,rgba(99,150,245,0.10),transparent 60%)",
    style: {
      padding: '96px 24px 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(340px,1fr))',
      gap: '56px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    size: "page",
    eyebrow: "Where we are",
    title: "Early, and Not Hiding It",
    maxWidth: "18ch"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: '24px 0 20px',
      maxWidth: '64ch',
      textWrap: 'pretty'
    }
  }, "We don't have a customer roster yet, and we're not going to pretend otherwise. What we have is seven years spent installing and servicing security systems into businesses like yours, four years designing this system specifically for laundromats, and a founding pilot starting now."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: '0 0 20px',
      maxWidth: '64ch',
      textWrap: 'pretty'
    }
  }, "We're bringing on a limited number of founding stores as we launch. If you want to be one of the first with real, documented results \u2014 reach out directly."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      maxWidth: '64ch',
      textWrap: 'pretty'
    }
  }, "Pilot terms are transparent from day one. The pilot group will be our proof of concept, and we can't wait to show laundromat owners across the country how we can improve their lives.")), /*#__PURE__*/React.createElement(Grid, {
    min: 140,
    gap: 16
  }, /*#__PURE__*/React.createElement(StatTile, {
    size: "lg",
    value: "7",
    label: "Years installing physical security"
  }), /*#__PURE__*/React.createElement(StatTile, {
    size: "lg",
    value: "4",
    label: "Years designing for laundromats"
  }), /*#__PURE__*/React.createElement(StatTile, {
    size: "lg",
    tone: "accent",
    value: "Now",
    label: "Founding pilot open"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--sf-border-default)',
      borderRadius: 'var(--sf-radius-lg)',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--sf-ink-780)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: C.A + 'shiftfree-silhouette.png',
    alt: "ShiftFree mark",
    style: {
      width: '100%',
      height: 'auto',
      objectFit: 'contain'
    }
  }))))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md",
    style: {
      padding: '112px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container-prose)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Founder",
    size: "sm",
    title: "Built by Someone Who's Actually Installed This",
    maxWidth: "24ch",
    style: {
      marginBottom: '28px'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '19px',
      lineHeight: 1.68,
      color: 'var(--sf-text-body-strong)',
      margin: '0 0 20px',
      textWrap: 'pretty'
    }
  }, "Hi, I'm Connor. I spent seven years running a physical security company, putting access control and monitoring into businesses like yours."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '19px',
      lineHeight: 1.68,
      color: 'var(--sf-text-body-strong)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, "The path started with one owner. We talked for months about what he actually wanted: a store that could stay open past the hours he could staff, without leaving the door unlocked and hoping. He was paying tens of thousands a year for someone to sit and watch a dryer. ShiftFree is what came out of those conversations."))), /*#__PURE__*/React.createElement(Section, {
    id: "contact"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container-narrow)',
      margin: '0 auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(36px,5.2vw,64px)',
      lineHeight: 1,
      letterSpacing: 'var(--sf-tracking-hero)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 22px',
      textWrap: 'balance'
    }
  }, "Ready to Get Your Life Back?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-lead)',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: '0 0 34px',
      textWrap: 'pretty'
    }
  }, "In 15 minutes, we'll show you exactly what SafeSpin24 saves at your store \u2014 and what your nights could look like without it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '14px',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    href: 'tel:1' + C.phone.replace(/[^0-9]/g, '')
  }, "Schedule Your Call"), /*#__PURE__*/React.createElement(Button, {
    variant: "mono",
    href: 'tel:1' + C.phone.replace(/[^0-9]/g, '')
  }, "Prefer to call? ", C.phone)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-meta)',
      color: 'var(--sf-text-faint)',
      letterSpacing: 'var(--sf-tracking-meta)',
      margin: '22px 0 0'
    }
  }, "No commitment \xB7 No pressure \xB7 Just answers"))));
}
window.CompanyScreen = CompanyScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CompanyScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
const {
  SectionHeading,
  Button,
  Pill,
  Card,
  StatTile,
  CheckItem,
  BrandMarquee,
  PainCard,
  CtaBand,
  Footnote,
  Eyebrow
} = window.ShiftFreeDesignSystem_a724fd;
function HomeScreen({
  go
}) {
  const C = window.SF_CONTENT;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '104px 24px 88px',
      background: 'var(--sf-glow-hero-left),var(--sf-glow-hero-right),var(--sf-bg-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(380px,1fr))',
      gap: '64px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Pill, {
    dot: true,
    style: {
      marginBottom: '28px'
    }
  }, "Launching Early 2026 \u2014 ShiftFree, Powered by SafeSpin24"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'var(--sf-size-hero)',
      lineHeight: 0.98,
      letterSpacing: 'var(--sf-tracking-hero)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 26px',
      textWrap: 'balance'
    }
  }, "You're Already Running an Unmanned Laundromat."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-lead)',
      lineHeight: 1.62,
      color: 'var(--sf-text-body)',
      margin: '0 0 28px',
      maxWidth: '62ch',
      textWrap: 'pretty'
    }
  }, "Anytime your attendant is off shift, running late, calling out, or can't solve the problem, your store is unmanned \u2014 you just don't have a system built for it. SafeSpin24 gives you one: credentialed access, live security monitoring with 2-way audio, and real-time support, running your store on your terms."), /*#__PURE__*/React.createElement("div", {
    style: {
      borderLeft: 'var(--sf-rule-accent)',
      padding: '4px 0 4px 20px',
      margin: '0 0 34px'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 600,
      fontSize: '17px',
      lineHeight: 1.5,
      color: 'var(--sf-fg-3)',
      letterSpacing: '-0.01em'
    }
  }, "One extra wash-dry-fold order a day pays for SafeSpin24. Every shift you can't cover tonight is money already left on the table.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '14px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => go('company')
  }, "Schedule a Call"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "md",
    onClick: () => go('revenue')
  }, "See the Math \u2014 What One Extra WDF Order a Day Is Worth")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-meta)',
      color: 'var(--sf-text-faint)',
      letterSpacing: 'var(--sf-tracking-meta)',
      margin: '20px 0 0'
    }
  }, "No commitment \xB7 15-minute call")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '18px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Framed, {
    src: C.A + 'safespin24-descriptor.jpeg',
    alt: "SafeSpin24 \u2014 The Integrated System"
  }), /*#__PURE__*/React.createElement(Grid, {
    min: 150,
    gap: 12
  }, /*#__PURE__*/React.createElement(StatTile, {
    value: "$750",
    label: "per month, flat"
  }), /*#__PURE__*/React.createElement(StatTile, {
    value: "24/7",
    label: "FreeByrd support"
  }), /*#__PURE__*/React.createElement(StatTile, {
    value: "~4 hrs",
    label: "typical install"
  }))))), /*#__PURE__*/React.createElement(BrandMarquee, {
    marks: C.marks
  }), /*#__PURE__*/React.createElement(Section, {
    pad: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '24px',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(26px,3vw,38px)',
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: 0
    }
  }, "$750 a month."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 0 0',
      fontSize: '16px',
      color: 'var(--sf-text-body)'
    }
  }, "First and last month due at installation. 1-year minimum term. No down payment, no CapEx.")), /*#__PURE__*/React.createElement(Button, {
    variant: "outlineAccent",
    size: "md",
    onClick: () => go('pricing')
  }, "See everything that's included \u2192"))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Why owners call",
    title: "Real Outcomes. Real Freedom. Real Money in Your Pocket.",
    maxWidth: "22ch",
    style: {
      marginBottom: '56px'
    }
  }), /*#__PURE__*/React.createElement(Grid, {
    min: 300
  }, C.pillars.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.title,
    tone: p.accent ? 'accent' : 'default',
    pad: "lg"
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tracking: "marquee",
    style: {
      marginBottom: '18px',
      letterSpacing: '0.18em'
    }
  }, p.kicker), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'var(--sf-size-h3)',
      lineHeight: 'var(--sf-leading-title)',
      letterSpacing: 'var(--sf-tracking-h3)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 14px',
      textWrap: 'pretty'
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 'var(--sf-leading-body)',
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, p.body)))), /*#__PURE__*/React.createElement(Footnote, {
    marker: "1",
    style: {
      marginTop: '32px'
    }
  }, "Based on $15\u2013$20/hr regional wage rates for one 8-hour attendant shift, before payroll burden, turnover, and scheduling overhead. Your number depends on your store \u2014 we'll calculate it on the call. Live security monitoring with 2-way audio is included for one 8-hour shift; additional shifts are priced separately.")), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "split",
    title: "If You Own a Laundromat, You Already Know This List",
    lead: "None of this is a staffing problem. It's a systems problem \u2014 and it has a fix.",
    maxWidth: "none",
    style: {
      marginBottom: '56px'
    }
  }), /*#__PURE__*/React.createElement(Slab, {
    columns: 3
  }, C.pains.map(p => /*#__PURE__*/React.createElement(PainCard, {
    key: p.num,
    num: p.num,
    question: p.q,
    answer: p.a
  })))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "The shift",
    title: "From Running It to Owning It. There's a Difference.",
    maxWidth: "26ch",
    style: {
      marginBottom: '56px'
    }
  }), /*#__PURE__*/React.createElement(Grid, {
    min: 360,
    gap: 24
  }, /*#__PURE__*/React.createElement(Card, {
    pad: "lg",
    style: {
      background: 'var(--sf-ink-780)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '15px',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--sf-fg-10)',
      margin: '0 0 26px'
    }
  }, "Your current reality"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '18px'
    }
  }, C.before.map(b => /*#__PURE__*/React.createElement(CheckItem, {
    key: b,
    state: "no"
  }, b)))), /*#__PURE__*/React.createElement(Card, {
    tone: "accent",
    pad: "lg"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '15px',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--sf-teal-300)',
      margin: '0 0 26px'
    }
  }, "With SafeSpin24"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '18px'
    }
  }, C.after.map(a => /*#__PURE__*/React.createElement(CheckItem, {
    key: a
  }, a)))))), /*#__PURE__*/React.createElement(CtaBand, {
    body: "In 15 minutes, we'll show you exactly what SafeSpin24 saves at your store \u2014 and what your nights could look like without it.",
    phone: C.phone
  }));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PricingScreen.jsx
try { (() => {
const {
  SectionHeading,
  PriceCard,
  Button,
  CheckItem,
  Card,
  StepRow,
  FaqItem,
  CtaBand
} = window.ShiftFreeDesignSystem_a724fd;
function PricingScreen({
  go
}) {
  const C = window.SF_CONTENT;
  const [faq, setFaq] = React.useState(0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    pad: "md",
    glow: "var(--sf-glow-page-top)",
    style: {
      padding: '96px 24px 80px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    size: "page",
    eyebrow: "Pricing",
    title: "One Flat Rate. No Tiers to Compare.",
    maxWidth: "20ch",
    lead: "No down payment. No CapEx. First and last month due at installation, 1-year minimum term."
  })), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md"
  }, /*#__PURE__*/React.createElement(Grid, {
    min: 340,
    gap: 24,
    style: {
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(PriceCard, {
    note: "Flat. Every store, every month.",
    footnote: "No down payment \xB7 No CapEx required \xB7 First & last due at install \xB7 1-year minimum term"
  }, /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: '0 0 34px',
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '16px'
    }
  }, C.includes.map(i => /*#__PURE__*/React.createElement(CheckItem, {
    key: i
  }, i))), /*#__PURE__*/React.createElement(Button, {
    onClick: () => go('company')
  }, "Schedule Your Call")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '20px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      background: 'var(--sf-ink-780)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '21px',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 14px'
    }
  }, "Want more coverage?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, "Additional live-monitoring shifts beyond the first are $100/month per camera \u2014 a standard 2-camera store adding a second monitored shift is $200/month. Going fully 24/7 is a level-up you choose, not something we assume you need on day one. Standard install includes 2 cameras (entry + shop floor); if your site only has one, we'll supply and install the second at your cost.")), /*#__PURE__*/React.createElement(Card, {
    style: {
      background: 'var(--sf-ink-780)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: '21px',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 14px'
    }
  }, "Why not a $2,000 DIY setup?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, "A smart lock and a couple of cameras leave you with hardware nobody is watching, and nobody coming to fix it when it fails. SafeSpin24 is a monitored, serviced system \u2014 not a pile of hardware you maintain yourself.")), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--sf-border-default)',
      borderRadius: 'var(--sf-radius-card)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: C.A + 'spinwatch24.png',
    alt: "SpinWatch24 \u2014 Live monitoring and 2-way audio",
    style: {
      width: '100%',
      height: 'auto',
      objectFit: 'contain'
    }
  }))))), /*#__PURE__*/React.createElement(Section, {
    pad: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1000px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "What happens after the call",
    size: "sm",
    title: "Six Steps to a Business That Runs Without You in the Room",
    maxWidth: "26ch",
    style: {
      marginBottom: '44px'
    }
  }), /*#__PURE__*/React.createElement(Slab, {
    radius: "var(--sf-radius-panel)"
  }, C.steps.map(s => /*#__PURE__*/React.createElement(StepRow, {
    key: s.num,
    num: s.num,
    title: s.title,
    body: s.body
  }))))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '920px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(30px,4vw,50px)',
      letterSpacing: '-0.035em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 44px'
    }
  }, "Questions owners ask"), /*#__PURE__*/React.createElement(Slab, null, C.faq.map((it, i) => /*#__PURE__*/React.createElement(FaqItem, {
    key: i,
    question: it.q,
    answer: it.a,
    open: faq === i,
    onToggle: () => setFaq(faq === i ? -1 : i)
  }))))), /*#__PURE__*/React.createElement(CtaBand, {
    body: "In 15 minutes, we'll show you exactly what SafeSpin24 saves at your store \u2014 and what your nights could look like without it.",
    phone: C.phone
  }));
}
window.PricingScreen = PricingScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PricingScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/RevenueScreen.jsx
try { (() => {
const {
  SectionHeading,
  ChoiceChip,
  DataTable,
  Card,
  CtaBand,
  Footnote,
  Eyebrow
} = window.ShiftFreeDesignSystem_a724fd;
function RevenueScreen() {
  const C = window.SF_CONTENT;
  const V = C.ORDER_VALUE;
  const [orders, setOrders] = React.useState(1);
  const [hoverMulti, setHoverMulti] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '96px 24px 72px',
      background: 'radial-gradient(900px 480px at 10% -10%,rgba(95,227,211,0.10),transparent 60%),var(--sf-bg-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(360px,1fr))',
      gap: '56px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    size: "page",
    eyebrow: "WDF-Access",
    title: "A Revenue Stream You're Currently Turning Away",
    maxWidth: "24ch"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: '24px 0 28px',
      maxWidth: 'var(--sf-measure-lead)',
      textWrap: 'pretty'
    }
  }, "Traditional wash-dry-fold programs run on your counter hours. SafeSpin24 WDF Access extends secure drop-off and pick-up beyond them \u2014 on the customer's schedule, not the store's. At the 2025 industry benchmark of $44.19 per drop-off order, a handful of extra customers a day is real, incremental revenue, without adding a shift to staff it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: '14px',
      border: '1px solid var(--sf-teal-a30)',
      borderRadius: 'var(--sf-radius-lg)',
      padding: '18px 24px',
      background: 'var(--sf-teal-a06)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: '44px',
      letterSpacing: '-0.04em',
      color: 'var(--sf-teal-300)',
      lineHeight: 1
    }
  }, "$44.19"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--sf-fg-11)',
      maxWidth: '20ch',
      lineHeight: 'var(--sf-leading-label)'
    }
  }, "2025 benchmark average, drop-off WDF order", /*#__PURE__*/React.createElement("sup", null, "2")))), /*#__PURE__*/React.createElement(Framed, {
    src: C.A + 'wdf-access.jpeg',
    alt: "WDF-Access \u2014 Drop off, pick up service"
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--sf-accent-band)',
      borderTop: '1px solid var(--sf-teal-a30)',
      borderBottom: '1px solid var(--sf-teal-a30)',
      padding: '44px 24px'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto',
      textAlign: 'center',
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(20px,2.6vw,32px)',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-text-heading)',
      textTransform: 'uppercase',
      lineHeight: 1.2
    }
  }, "One additional WDF order per day will pay for SafeSpin24.")), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'var(--sf-size-h2-sm)',
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 12px'
    }
  }, "Run your own number"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '17px',
      lineHeight: 1.6,
      color: 'var(--sf-text-body)',
      margin: '0 0 32px',
      maxWidth: '60ch'
    }
  }, "Pick how many additional drop-off orders a day your store could realistically capture."), /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Additional WDF orders per day",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '10px',
      marginBottom: '36px'
    }
  }, [1, 2, 3, 4, 5].map(n => /*#__PURE__*/React.createElement(ChoiceChip, {
    key: n,
    active: n === orders,
    onClick: () => setOrders(n)
  }, n === 1 ? '1 order/day' : n + ' orders/day'))), /*#__PURE__*/React.createElement(Grid, {
    min: 240
  }, /*#__PURE__*/React.createElement(Card, {
    pad: "md",
    style: {
      background: 'var(--sf-ink-780)',
      borderRadius: 'var(--sf-radius-card)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted",
    style: {
      marginBottom: '14px',
      letterSpacing: 'var(--sf-tracking-label)',
      fontSize: 'var(--sf-size-label)'
    }
  }, "Daily revenue"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(30px,4vw,46px)',
      letterSpacing: '-0.035em',
      color: 'var(--sf-text-heading)',
      margin: 0,
      lineHeight: 1
    }
  }, money(V * orders, true))), /*#__PURE__*/React.createElement(Card, {
    tone: "accent",
    pad: "md"
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted",
    style: {
      marginBottom: '14px',
      letterSpacing: 'var(--sf-tracking-label)',
      fontSize: 'var(--sf-size-label)',
      color: 'var(--sf-teal-300)'
    }
  }, "Annual revenue, one store"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(30px,4vw,46px)',
      letterSpacing: '-0.035em',
      color: 'var(--sf-text-heading)',
      margin: 0,
      lineHeight: 1
    }
  }, money(Math.round(V * orders * 365), false))), /*#__PURE__*/React.createElement(Card, {
    pad: "md",
    style: {
      background: 'var(--sf-ink-780)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted",
    style: {
      marginBottom: '14px',
      letterSpacing: 'var(--sf-tracking-label)',
      fontSize: 'var(--sf-size-label)'
    }
  }, "Annual, five stores"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(30px,4vw,46px)',
      letterSpacing: '-0.035em',
      color: 'var(--sf-text-heading)',
      margin: 0,
      lineHeight: 1
    }
  }, money(Math.round(V * orders * 365 * 5), false))))), /*#__PURE__*/React.createElement(Section, {
    pad: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '80px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(26px,3.2vw,38px)',
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 10px'
    }
  }, "Annual incremental revenue per store"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: '0.1em',
      color: 'var(--sf-text-faint)',
      margin: '0 0 26px'
    }
  }, "Swipe horizontally on smaller screens \u2192"), /*#__PURE__*/React.createElement(DataTable, {
    columns: ['Additional WDF orders/day', 'Daily revenue', 'Annual revenue'],
    activeRow: orders - 1,
    onRowActivate: i => setOrders(i + 1),
    rows: [1, 2, 3, 4, 5].map(n => [String(n), money(V * n, true), money(V * n * 365, true)])
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(26px,3.2vw,38px)',
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 10px'
    }
  }, "Multi-store revenue potential"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--sf-size-body)',
      lineHeight: 1.6,
      color: 'var(--sf-text-body)',
      margin: '0 0 8px',
      maxWidth: '60ch'
    }
  }, "Additional WDF orders per day, per store."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-mono)',
      fontSize: 'var(--sf-size-eyebrow)',
      letterSpacing: '0.1em',
      color: 'var(--sf-text-faint)',
      margin: '0 0 26px'
    }
  }, "Hover or tap a row to isolate it \xB7 swipe horizontally on smaller screens \u2192"), /*#__PURE__*/React.createElement(DataTable, {
    minWidth: 760,
    columns: ['Orders/day/store', '1 store', '2 stores', '3 stores', '4 stores', '5 stores'],
    activeRow: hoverMulti,
    onRowActivate: setHoverMulti,
    rows: [1, 2, 3, 4, 5].map(o => [String(o)].concat([1, 2, 3, 4, 5].map(s => money(Math.round(V * o * 365 * s), false))))
  }), /*#__PURE__*/React.createElement(Footnote, {
    marker: "2",
    style: {
      marginTop: '24px'
    }
  }, "Illustrative annual revenue based on a $44.19 average drop-off WDF order value and 365 operating days. These figures are revenue before fulfillment labor, supplies, utilities, payment processing, rewash/rework, customer remedies, and other costs. Actual results depend on local demand, pricing, production capacity, customer adoption, service quality, and the operator's WDF economics.")))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container-prose)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '19px',
      lineHeight: 1.6,
      color: 'var(--sf-text-body)',
      margin: '0 0 20px'
    }
  }, "The question is not whether every laundromat should become a WDF operator."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'clamp(24px,3.2vw,38px)',
      lineHeight: 1.18,
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 24px',
      textWrap: 'balance'
    }
  }, "The question is: how much WDF demand is currently unavailable because potential customers cannot use the service on their schedule?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '17.5px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, "For some stores, the answer may be little or none. For others, one to five incremental WDF orders per day can materially change the economics of a location."))), /*#__PURE__*/React.createElement(CtaBand, {
    body: "In 15 minutes, we'll show you exactly what SafeSpin24 saves at your store \u2014 and what your nights could look like without it.",
    phone: C.phone
  }));
}
window.RevenueScreen = RevenueScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/RevenueScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Shell.jsx
try { (() => {
// Section wrapper: the site alternates #080D12 and #0A1016 bands, each closed by a hairline.
function Section({
  children,
  tone = 'page',
  pad = 'lg',
  glow,
  id,
  style
}) {
  const bg = [glow || null, tone === 'alt' ? 'var(--sf-bg-alt)' : 'var(--sf-bg-page)'].filter(Boolean).join(',');
  return /*#__PURE__*/React.createElement("section", {
    id: id,
    style: Object.assign({
      background: bg,
      padding: pad === 'sm' ? '56px 24px' : pad === 'md' ? '96px 24px' : '120px 24px',
      borderBottom: '1px solid var(--sf-border-default)'
    }, style)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--sf-container)',
      margin: '0 auto'
    }
  }, children));
}
function Grid({
  min = 330,
  gap = 20,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: Object.assign({
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(' + min + 'px,1fr))',
      gap: gap + 'px'
    }, style)
  }, children);
}

// 1px-gap slab: children get hairline dividers with no borders of their own.
function Slab({
  columns = 1,
  radius = 'var(--sf-radius-card)',
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: columns > 1 ? 'grid' : 'flex',
      flexDirection: columns > 1 ? undefined : 'column',
      gridTemplateColumns: columns > 1 ? 'repeat(auto-fit,minmax(320px,1fr))' : undefined,
      gap: '1px',
      background: 'var(--sf-line-12)',
      border: '1px solid var(--sf-line-12)',
      borderRadius: radius,
      overflow: 'hidden'
    }
  }, children);
}
function Framed({
  src,
  alt,
  ratio,
  style
}) {
  return /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    decoding: "async",
    style: Object.assign({
      width: '100%',
      height: 'auto',
      objectFit: 'contain',
      borderRadius: 'var(--sf-radius-card)',
      border: '1px solid var(--sf-line-14)'
    }, style)
  });
}
function money(n, cents) {
  return '$' + n.toLocaleString('en-US', {
    minimumFractionDigits: cents ? 2 : 0,
    maximumFractionDigits: cents ? 2 : 0
  });
}
Object.assign(window, {
  Section,
  Grid,
  Slab,
  Framed,
  money
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SystemScreen.jsx
try { (() => {
const {
  SectionHeading,
  Card,
  HubCard,
  CtaBand,
  Eyebrow
} = window.ShiftFreeDesignSystem_a724fd;
function SystemScreen() {
  const C = window.SF_CONTENT;
  const moat = [{
    kicker: 'Point 01',
    title: 'We Created It. We Install It. We Maintain It.',
    body: 'We created it, we install it, we service it, and we maintain it in most major cities across the country. This includes a quarterly service visit for as long as you\u2019re a customer. That\u2019s a business relationship, not a subcontractor list.',
    img: C.A + 'safespin24-descriptor.jpeg',
    alt: 'SafeSpin24 — the integrated system',
    flip: false
  }, {
    kicker: 'Point 02',
    title: 'One Hub, Not Five Vendors.',
    body: "Everywhere else, you're stitching together a lock company, a camera company, a monitoring service, and a support line — and hoping they talk to each other when something goes wrong. ShiftFree is the only product that unifies physical security, live monitoring, and Tier 1/2 customer support into one system, run from one app: ByrdView.",
    img: C.A + 'byrdview.jpeg',
    alt: 'ByrdView — operations control center',
    flip: true
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    pad: "md",
    glow: "var(--sf-glow-page-top)",
    style: {
      padding: '96px 24px 80px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    size: "page",
    eyebrow: "The moat",
    title: "SafeSpin24 Is the Only Fully Integrated Prop Tech in the Market",
    maxWidth: "26ch",
    lead: "A camera company sells you a camera. A lock company sells you a lock. ShiftFree is the only company that owns the whole system \u2014 and stands behind it."
  })), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md",
    style: {
      padding: '112px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '96px'
    }
  }, moat.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.kicker,
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(340px,1fr))',
      gap: '56px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      order: m.flip ? 2 : 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '18px'
    }
  }, m.kicker), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(28px,3.4vw,42px)',
      lineHeight: 1.06,
      letterSpacing: '-0.03em',
      color: 'var(--sf-text-heading)',
      margin: '0 0 20px',
      textWrap: 'balance'
    }
  }, m.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '17.5px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, m.body)), /*#__PURE__*/React.createElement("div", {
    style: {
      order: m.flip ? 1 : 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Framed, {
    src: m.img,
    alt: m.alt
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--sf-border-accent)',
      background: 'var(--sf-accent-wash-strong)',
      borderRadius: 'var(--sf-radius-panel)',
      padding: '40px 36px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 700,
      fontSize: 'var(--sf-size-h4)',
      letterSpacing: 'var(--sf-tracking-tight)',
      color: 'var(--sf-text-heading)',
      margin: '0 0 14px',
      textWrap: 'pretty'
    }
  }, "Why not just buy a smart lock and two cameras yourself?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '17.5px',
      lineHeight: 1.65,
      color: 'var(--sf-text-body-strong)',
      margin: 0,
      maxWidth: 'var(--sf-measure-body)',
      textWrap: 'pretty'
    }
  }, "Because nobody's watching them. SafeSpin24 gives you credentialed access that's always on, FreeByrd support around the clock, live security monitoring with 2-way audio during your scheduled shift, and a technician who already knows your door \u2014 we installed it.")))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(340px,1fr))',
      gap: '40px',
      alignItems: 'end',
      marginBottom: '52px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--sf-font-display)',
      fontWeight: 800,
      fontSize: 'clamp(38px,5vw,64px)',
      lineHeight: 0.98,
      letterSpacing: 'var(--sf-tracking-hero)',
      color: 'var(--sf-text-heading)',
      margin: 0
    }
  }, "The Hub"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '18px',
      lineHeight: 1.6,
      color: 'var(--sf-text-body)',
      margin: 0,
      textWrap: 'pretty'
    }
  }, "Everything you need to go unmanned, safely and on your terms.")), /*#__PURE__*/React.createElement(Grid, {
    min: 330
  }, C.hub.map(h => /*#__PURE__*/React.createElement(HubCard, {
    key: h.name,
    name: h.name,
    tag: h.tag,
    body: h.body,
    mark: h.mark,
    markRatio: h.ratio,
    tone: h.accent ? 'accent' : 'default',
    linkLabel: h.linkLabel,
    linkHref: h.linkHref
  })))), /*#__PURE__*/React.createElement(Section, {
    tone: "alt",
    pad: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1100px',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(Framed, {
    src: C.A + 'safespin24-grid.jpeg',
    alt: "The SafeSpin24 system: Guardian Entry Kit, SecureDoor24, SpinWatch24, ByrdView, FreeByrd and WDF-Access",
    style: {
      borderRadius: 'var(--sf-radius-panel)'
    }
  }))), /*#__PURE__*/React.createElement(CtaBand, {
    body: "In 15 minutes, we'll show you exactly what SafeSpin24 saves at your store \u2014 and what your nights could look like without it.",
    phone: C.phone
  }));
}
window.SystemScreen = SystemScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SystemScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/content.js
try { (() => {
// Copy lifted verbatim from the ShiftFree messaging draft (2026-08-20) and the site build.
window.SF_CONTENT = {
  phone: '757-837-3567',
  A: '../../assets/',
  nav: [{
    id: 'home',
    label: 'Home',
    href: '#home'
  }, {
    id: 'system',
    label: 'The System',
    href: '#system'
  }, {
    id: 'revenue',
    label: 'WDF Revenue',
    href: '#revenue'
  }, {
    id: 'pricing',
    label: 'Pricing',
    href: '#pricing'
  }, {
    id: 'company',
    label: 'Company',
    href: '#company'
  }],
  marks: [{
    src: '../../assets/marquee/guardian.png',
    ratio: 1,
    alt: 'Guardian Entry Kit — physical door hardware'
  }, {
    src: '../../assets/marquee/securedoor24.png',
    ratio: 1.8125,
    alt: 'SecureDoor24 — access control'
  }, {
    src: '../../assets/marquee/spinwatch24.png',
    ratio: 1.8125,
    alt: 'SpinWatch24 — live monitoring and 2-way audio'
  }, {
    src: '../../assets/marquee/byrdview.png',
    ratio: 1.8125,
    alt: 'ByrdView — operations control center'
  }, {
    src: '../../assets/marquee/freebyrd.png',
    ratio: 1.8125,
    alt: 'FreeByrd — virtual customer support'
  }, {
    src: '../../assets/marquee/wdf-access.png',
    ratio: 1.7219,
    alt: 'WDF-Access — drop off, pick up service'
  }, {
    src: '../../assets/marquee/safespin24.png',
    ratio: 1.8333,
    alt: 'SafeSpin24 — the integrated system'
  }],
  pillars: [{
    kicker: 'Labor',
    title: 'Save as Many Labor Hours as You Choose',
    body: "Start with a single shift, expand to full 24/7 operation, or go fully unmanned. Work the shift you want, skip the one you don't, and get your evenings back. It's your choice.",
    accent: false
  }, {
    kicker: '$30,000–$58,000¹ potential annual savings',
    title: 'Put It Back in Your Pocket',
    body: 'Reduce or redeploy coverage hours. That money goes to you, not a payroll line.',
    accent: true
  }, {
    kicker: '24/7 peace of mind',
    title: 'Covered, Not Just Watched',
    body: 'FreeByrd handles routine requests any time, day or night. Live security monitoring with 2-way audio covers your scheduled shift — add more as you extend further into unattended hours. Your phone stops being the support desk.',
    accent: false
  }],
  pains: [{
    num: '01',
    q: 'Your attendant just called out. Again.',
    a: "No-shows, no call, and now you're the one covering the shift — or closing early."
  }, {
    num: '02',
    q: "You closed at 9pm because you can't staff nights.",
    a: 'Every hour after that is revenue sitting on the table, unclaimed.'
  }, {
    num: '03',
    q: "Someone's loitering in your lobby and you're 40 minutes away.",
    a: "Cameras record it. Nobody's actually watching it, and nobody responds to it."
  }, {
    num: '04',
    q: "Your phone rings after work hours and it's not good news.",
    a: 'A water leak, a jammed machine, a refund request, an unruly customer, a mess, a nasty bathroom, a customer who feels unsafe.'
  }, {
    num: '05',
    q: "You've turned down wash-dry-fold drop-offs because nobody's there after 6.",
    a: "A second revenue stream you can't say yes to yet — not because customers don't want it."
  }, {
    num: '06',
    q: "You can't remember your last real vacation.",
    a: "When was the last time the business didn't call while you were away from it?"
  }],
  before: ["Open hours capped by who's on the clock", 'Labor costs eating into your margin', 'Your personal phone is the support desk', 'Tied to one location, one schedule', 'Cameras record incidents — nobody responds'],
  after: ['True 24/7, overnight-only, or hybrid — your call', 'Controlled door access and live security monitoring with 2-way audio let you safely cut as many labor hours as you choose. No one gets in without a credential.', 'FreeByrd resolves routine requests on the spot, with the authority you give it. You decide what escalates to you.', 'Manage every store from your phone, anywhere', 'Live security monitoring with 2-way audio — real response'],
  hub: [{
    name: 'Guardian Entry Kit',
    tag: 'Commercial-grade hardware',
    mark: '../../assets/marquee/guardian.png',
    ratio: 1,
    body: 'The physical foundation: heavy-duty deadlatch, electric strike, and push/pull paddle, professionally installed and commissioned to preserve safe egress and allow your door to "speak" with the access controller. Built for constant laundromat traffic — not a residential smart lock bolted onto a commercial door.'
  }, {
    name: 'SecureDoor24',
    tag: 'Smart access control',
    mark: '../../assets/marquee/securedoor24.png',
    ratio: 1.8125,
    body: 'Credentialed entry, schedules, and permissions you set and change remotely, from your phone. Every entry is logged — who, when, how — so "unmanned" never means "unaccountable." SpinWatch24 incident reports and footage from your standalone WDF drop-zone camera live here too, all inside ByrdView.'
  }, {
    name: 'SpinWatch24',
    tag: 'Live monitoring · 2-way audio',
    mark: '../../assets/marquee/spinwatch24.png',
    ratio: 1.8125,
    accent: true,
    body: 'A real person watching your store during your scheduled shift — not a recording waiting to be reviewed after something\u2019s already happened. 2-way audio means real-time deterrence and incident response, not just evidence. Base subscription includes one 8-hour shift covering up to 2 cameras.'
  }, {
    name: 'FreeByrd',
    tag: 'Your 24/7 virtual hero',
    mark: '../../assets/marquee/freebyrd.png',
    ratio: 1.8125,
    body: "Engages every customer with knowledge and empathy, and resolves routine requests on the spot — an eligible door release, a common question — when you've given it permission to. When it doesn't have the authority or the confidence, it escalates straight to you."
  }, {
    name: 'ByrdView',
    tag: 'The brains supporting the system',
    mark: '../../assets/marquee/byrdview.png',
    ratio: 1.8125,
    accent: true,
    body: 'One dashboard for every store: access events, support cases, live monitoring status, and what\u2019s actually happening across your locations — instead of five vendor portals that don\u2019t talk to each other.'
  }, {
    name: 'WDF-Access',
    tag: 'Drop off, pick up — on their schedule',
    mark: '../../assets/marquee/wdf-access.png',
    ratio: 1.7219,
    body: 'Designed as an overlay for your current WDF Management System to allow customers to use the service at their convenience.',
    linkLabel: 'See more at www.beshiftfree.com/wdf-access',
    linkHref: 'https://www.beshiftfree.com/wdf-access'
  }],
  steps: [{
    num: '01',
    title: 'Schedule a Call',
    body: 'We assess your store, your goals, and discuss how SafeSpin24 can help not only your business but improve your life.'
  }, {
    num: '02',
    title: 'Virtual Site Visit',
    body: 'We perform a virtual site visit to log and photograph your facility (inside and outside), door hardware, installed camera(s), ceiling access, electrical access, and WDF setup, if applicable.'
  }, {
    num: '03',
    title: 'Schedule Installation',
    body: 'We lock in your installation date.'
  }, {
    num: '04',
    title: 'Pre-Installation',
    body: 'Set up your ByrdView account and receive your onboarding materials.'
  }, {
    num: '05',
    title: 'Installation Day',
    body: 'Installation and a walk-around with your technician.'
  }, {
    num: '06',
    title: 'Reclaim Your Life',
    body: 'Work or monitor from anywhere, generate additional revenue, reduce costs, reclaim your life, have more time for what you want to do, and develop the business you planned.'
  }],
  includes: ['The SafeSpin24 Hub — Guardian Entry Kit, SecureDoor24, SpinWatch24, ByrdView, and FreeByrd', 'Credentialed access, always on the schedule you determine — the only way in is with a credential', 'Live security monitoring with 2-way audio — 1 shift included, covering up to 2 cameras (entry + shop)', 'FreeByrd support, around the clock', 'ByrdView owner dashboard, every store, one login', 'Professional installation, done by us', 'Quarterly nationwide service visit — included'],
  faq: [{
    q: 'What happens if a customer has a problem outside your monitored hours?',
    a: 'FreeByrd is available any time, day or night, to engage the customer and resolve routine, verified requests on the spot. Anything that needs your judgment or authority is escalated straight to you or your manager on duty. Live, 2-way-audio response from SpinWatch24 is active during your scheduled monitoring shift — add shifts as you extend further into unattended hours.'
  }, {
    q: 'What does it cost?',
    a: '$750/month, flat. No down payment, no CapEx — first and last month due at installation, 1-year minimum term.'
  }, {
    q: 'How long does installation take?',
    a: 'A typical single-door installation is about four hours, done by our own nationwide install team — not a third party.'
  }, {
    q: 'Can I manage multiple locations?',
    a: 'Yes — ByrdView gives you one dashboard across every store you run, with access, monitoring, and support all in one place.'
  }],
  footerColumns: [{
    title: 'Site',
    links: [{
      label: 'Home',
      href: '#home'
    }, {
      label: 'The System',
      href: '#system'
    }, {
      label: 'WDF Revenue',
      href: '#revenue'
    }, {
      label: 'Pricing',
      href: '#pricing'
    }, {
      label: 'Company',
      href: '#company'
    }]
  }, {
    title: 'Contact',
    links: [{
      label: 'beshiftfree.com',
      href: 'https://beshiftfree.com'
    }, {
      label: '757-837-3567',
      href: 'tel:17578373567'
    }, {
      label: 'Legal Disclosures',
      href: '#legal'
    }]
  }, {
    title: 'Follow',
    links: [{
      label: 'LinkedIn',
      href: '#linkedin'
    }, {
      label: 'YouTube',
      href: '#youtube'
    }, {
      label: 'Instagram',
      href: '#instagram'
    }]
  }],
  ORDER_VALUE: 44.19
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/content.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CheckItem = __ds_scope.CheckItem;

__ds_ns.ChoiceChip = __ds_scope.ChoiceChip;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.BrandMarquee = __ds_scope.BrandMarquee;

__ds_ns.CtaBand = __ds_scope.CtaBand;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.FaqItem = __ds_scope.FaqItem;

__ds_ns.Footnote = __ds_scope.Footnote;

__ds_ns.HubCard = __ds_scope.HubCard;

__ds_ns.PainCard = __ds_scope.PainCard;

__ds_ns.PriceCard = __ds_scope.PriceCard;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.StepRow = __ds_scope.StepRow;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

})();
