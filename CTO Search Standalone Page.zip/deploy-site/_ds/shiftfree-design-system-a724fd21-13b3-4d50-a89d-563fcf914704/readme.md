# ShiftFree Design System

ShiftFree is an early-stage prop-tech company (ShiftFree LLC, launching early 2026) selling
**SafeSpin24** — an integrated system that lets laundromat owners run unmanned or partly-unmanned
stores: credentialed door access, live human security monitoring with 2-way audio, 24/7 virtual
customer support, and one owner dashboard. One flat price: $750/month. Founder: Connor. Phone:
757-837-3567. Site: beshiftfree.com.

**The product family (all six live under SafeSpin24):**
| Product | What it is |
|---|---|
| Guardian Entry Kit | Physical door hardware — deadlatch, electric strike, push/pull paddle |
| SecureDoor24 | Smart access control: credentials, schedules, entry logs |
| SpinWatch24 | Live security monitoring + 2-way audio, staffed by a real person |
| FreeByrd | 24/7 virtual customer support agent ("your virtual hero") |
| ByrdView | Operations control center / owner dashboard |
| WDF-Access | After-hours wash-dry-fold drop-off and pick-up |

## Sources this system was built from
- **Design project (primary source of truth):** `ShiftFree Website.dc.html` and `CtaBand.dc.html` in
  the Claude design project `https://claude.ai/design/p/bf2a23f7-f42e-4362-98a5-23f7f195b7a6`
  — a full, built recreation of the marketing site. Every colour, size, radius and spacing value in
  `tokens/` is lifted verbatim from that file, not rounded or re-derived.
- **Copy source:** `guidelines/source-messaging-2026-08-20.md` (the client's "BeShiftFree Messaging
  Update, 08-20-26" working draft) — the approved wording for every page.
- **Brand imagery:** the logo lockups, product marks and product renders in that project's
  `assets/` and `uploads/website refresh/` folders, copied here into `assets/`.
- **No Figma file, no codebase, and no slide deck were provided.** There is no product (ByrdView) UI
  in any source, so no app UI kit exists — see "Gaps" below.

## Content fundamentals
The voice is a **direct, plain-spoken operator talking to another operator**. It leads with the
reader's problem, in the reader's words, and refuses to oversell.

- **Second person, always.** "You're Already Running an Unmanned Laundromat." "Your attendant just
  called out. Again." The company is "we", and appears far less often than "you".
- **Headlines are Title Case with real punctuation** — full stops inside headlines are normal and
  used for rhythm: "From Running It to Owning It. There's a Difference." "One Flat Rate. No Tiers to
  Compare." Body copy is sentence case.
- **Contractions everywhere** ("you're", "can't", "we're"). Formal register is off-brand.
- **Em dashes carry the turn in the argument**, and the middle-dot separator carries trust lines:
  "No commitment · 15-minute call", "No down payment · No CapEx required · First & last due at install".
- **Named pain, then the fix.** The pain section is six literal owner sentences, each followed by one
  flat consequence line. Then the bridge: "None of this is a staffing problem. It's a systems
  problem — and it has a fix."
- **Honesty as a selling point.** "Early, and Not Hiding It." "We don't have a customer roster yet,
  and we're not going to pretend otherwise." Never invent customers, logos, testimonials or counts.
- **Every number is footnoted.** Savings and revenue claims carry a superscript and a qualifier
  paragraph ("Illustrative annual revenue based on a $44.19 average drop-off WDF order value…").
  If you write a figure, write its footnote.
- **Mono microcopy is uppercase and terse:** eyebrows ("THE SHIFT", "WHY OWNERS CALL"), stat captions
  ("PER MONTH, FLAT"), instructions ("Swipe horizontally on smaller screens →").
- **No emoji. Ever.** No exclamation marks. No "revolutionary/seamless/unlock" marketing filler. No
  jargon the owner wouldn't use — "unmanned", "shift", "drop-off", "WDF" are the vocabulary.
- **Product naming is strict:** ShiftFree (company) — Powered by SafeSpin24 (system). CamelCase with
  the 24 attached: SafeSpin24, SecureDoor24, SpinWatch24. "WDF-Access" hyphenated. Guardian Entry
  Kit in full.

## Visual foundations
**Palette.** A single dark theme. Backgrounds are near-black blue-greys that alternate band to band
(`#080D12` page ↔ `#0A1016` alt), with cards a half-step lighter (`#0C1218`). One accent family:
teal `#5FE3D3` (with `#8CF0E3` for text/fills) and a supporting sky blue `#63C7F5` that appears
**only** inside the CTA gradient and the top-right hero glow. Text is one cool grey ramp from
`#F2F7FA` headings down to `#6F8494` legal. No warm colour anywhere; no second accent; no
semantic red/amber/green system exists in the source (nothing in the site needed one).

**Type.** Three families, strictly divided by job. **Archivo** (600/700/800) for anything structural:
headlines, card titles, buttons, numbers, nav. **IBM Plex Sans** (400) for all prose. **IBM Plex
Mono** (400/500) for every label, eyebrow, caption, phone number and legal line. Display type is
tightly tracked (-0.03em to -0.05em) at 1.0 line-height and fluid via `clamp()`; prose is loose
(1.62–1.68) and capped at 62–80ch with `text-wrap: pretty`; headlines use `text-wrap: balance`.
Money is Archivo 800 with `font-variant-numeric: tabular-nums` in tables.

**Spacing & layout.** 1240px container, 24px gutters, 88px sticky header. Sections are 120px tall
vertically (96px for page-tops, 56px for utility bands), each closed by a 1px hairline — the hairline
is the section separator, not whitespace alone. Grids are always
`repeat(auto-fit,minmax(300–380px,1fr))` with a 20–24px gap, so the layout reflows without media
queries. Two-column splits use a 56px gap and `align-items:center`. Card padding is 32px (36px 32px
for the taller ones).

**Backgrounds.** No photography, no patterns, no textures, no illustration. Flat dark fills plus
large **radial glows** — teal from the top-left and blue from the top-right on hero sections, teal
from *below* on the CTA band (`at 50% 120%`). Imagery is limited to the supplied product renders:
dark, cool, glowing circuit-line 3D marks on near-black, always inside an 18px-radius hairline frame
with `object-fit: contain` (never cropped, never full-bleed).

**Borders, shadows, depth.** There are **no drop shadows in this system at all.** Depth comes from
(1) one hairline colour, `rgba(148,180,200,α)`, at 0.08–0.24 alpha, and (2) the radial glows. The
signature structural device is the **1px-gap slab**: a grid or flex column with `gap:1px` over a
hairline-coloured parent, rounded and clipped — the gap draws the dividers, the children carry no
borders (pain grid, steps, FAQ). Emphasis cards swap the flat fill for a teal wash
(`linear-gradient(180deg,rgba(95,227,211,.08),rgba(95,227,211,.01))`) plus a teal hairline. One
other emphasis device: a 2px teal left rule on the money line.

**Corner radii.** 8 (small clipped images) · 12 (mark tiles, stat tiles) · 14 (large stat tiles,
inline callouts) · 18 (cards, framed images, tables) · 20–22 (large panels, price card) · 999 (every
button, chip, nav item and pill). Nothing is square-cornered.

**Transparency & blur.** Used sparingly and only where the source does: the sticky header is
`rgba(10,16,22,0.86)` with a light backdrop blur; accent tints and hairlines are alpha; the marquee
uses a horizontal mask-image (`transparent → #000 8% → #000 92% → transparent`) to fade its edges
instead of a protection gradient or capsule.

**Motion.** Almost none. One continuous animation exists — the 42s linear product marquee
(`translateX(0 → -50%)`, list duplicated once). Everything else is a 0.22–0.3s ease transition on
**colour only**. No bounces, no springs, no scroll reveals, no parallax, no entrance animation. The
one transform in the system is the FAQ "+" rotating 45° to an ×.

**Hover / press states.** Filled buttons: `filter: brightness(1.08)` — no lift, no scale, no shadow.
Hairline buttons and links: border goes teal and the label goes `#8CF0E3`/`#96F1E5`. Cards and rows:
the fill lightens one step (`#0A1016 → #0D151C`, `#0B1116 → #0E151B`) or gains a teal tint
(`rgba(95,227,211,0.07)`) for the active table row. Selected states are the inverse: a solid
`#8CF0E3` fill with `#04141A` text (active nav item, active calculator chip). There is no separate
press state in the source, and nothing ever moves on interaction.

**Layout rules.** The header is sticky and full-width; nothing else is fixed. No modals, no toasts,
no overlays exist in the source. Tables scroll horizontally inside their rounded frame with a mono
instruction line above them.

## Iconography
ShiftFree has **no icon set and no icon font.** The source uses exactly one inline SVG glyph — an
18px teal check (`stroke-width 2.4`, round caps) — plus a hollow dusty-rose ring
(`rgba(180,140,140,0.4)`) as its negative counterpart, and a mono `+` character as the accordion
toggle. Arrows are the literal character `→` inside link text. Bullets and separators are the
middle dot `·`. Numbered lists use zero-padded mono numerals (`01`–`06`), not icons.

**Emoji are never used.** No CDN icon library is linked, and none was substituted — adding Lucide or
Heroicons here would invent a vocabulary the brand doesn't have. If a future surface genuinely needs
an icon set, that is a decision to make with the client, not a default.

What ShiftFree *does* have instead of icons is a set of **product marks**: seven glowing 3D renders
(`assets/marquee/*.png`) used at 72–110px inside rounded hairline tiles. Use those, at their real
aspect ratios, wherever a product needs a visual — never redraw them.

### Assets
- `assets/shiftfree-logo.png` — primary lockup (gradient ring mark + wordmark) on dark
- `assets/shiftfree-logo-tagline.png` — lockup with "Automation for unmanned spaces"
- `assets/shiftfree-logo-bw.png` — black-and-white lockup, used in the footer
- `assets/shiftfree-silhouette.png` — mark alone on dark
- `assets/mark-512.png` — favicon / app mark
- `assets/marquee/{guardian,securedoor24,spinwatch24,byrdview,freebyrd,wdf-access,safespin24}.png` — product marks
- `assets/{safespin24,safespin24-descriptor,safespin24-grid,byrdview,freebyrd,spinwatch24,securedoor24,wdf-access,guardian-entry-kit}.*` — full product renders / system diagrams

## Components
Reusable primitives, bundled and exposed on `window.ShiftFreeDesignSystem_a724fd`. This inventory
mirrors what the source site actually defines — nothing has been added speculatively.

**`components/core/`** — Button · Eyebrow · Pill · Card · StatTile · CheckItem · ChoiceChip
**`components/marketing/`** — SectionHeading · HubCard · PainCard · FaqItem · StepRow · PriceCard · CtaBand · BrandMarquee · DataTable · Footnote
**`components/navigation/`** — SiteHeader · SiteFooter

Each has a sibling `.d.ts` (props contract) and `.prompt.md` (what/when + usage). Each directory has
one `@dsCard` HTML showing its states.

**Intentional additions:** none. Every component above is a direct extraction of a pattern that
appears in the source site.

## Index
- `styles.css` — the only file consumers link; `@import`s everything below
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radii.css`, `effects.css`, `motion.css`
- `components/` — `core/`, `marketing/`, `navigation/` (see above)
- `ui_kits/website/` — five-page click-through recreation of beshiftfree.com; start at `index.html`, details in its `README.md`
- `guidelines/` — 21 foundation specimen cards (Colors, Type, Spacing, Brand) + `source-messaging-2026-08-20.md`
- `assets/` — logos, product marks, product renders
- `thumbnail.html` — project tile
- `SKILL.md` — Agent-Skills-compatible entry point

## Gaps and open questions
- **Fonts:** Archivo, IBM Plex Sans and IBM Plex Mono are loaded from Google Fonts, exactly as the
  source does. No licensed binaries were provided, so `tokens/fonts.css` has an `@import` rather
  than `@font-face` rules. These are the real brand fonts, not substitutes.
- **No product (ByrdView) UI exists** in any provided source, so there is no app UI kit — only the
  marketing site. ByrdView screens would need Figma or code to recreate honestly.
- **No slide template** was provided, so no sample slides were built.
- **No semantic colour system** (success/warning/error) and **no form components** exist, because the
  source site has no forms — CTAs are phone links.
- **Founder headshot/bio, and two FAQ answers**, were still open in the messaging draft and are left out.
